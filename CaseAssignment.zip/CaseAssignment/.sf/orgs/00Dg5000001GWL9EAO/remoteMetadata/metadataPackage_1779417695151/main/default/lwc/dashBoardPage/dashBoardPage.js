import { LightningElement,wire,api} from 'lwc';
import getActiveShift from '@salesforce/apex/DashboardController.getActiveShift';
import getAllCases from '@salesforce/apex/DashboardController.getAllCases';
import { NavigationMixin } from "lightning/navigation";

export default class DashBoardPage extends NavigationMixin(LightningElement) {

activeShift;
shiftError;

cases=[];
caseError;

columns=[
{
label:'Case Number',
fieldName:'CaseNumber',
type:'text'
},
{
label:'Assigned To',
fieldName:'OwnerName',
type:'text'
},
{
label:'Status',
fieldName:'Status',
type:'text'
},
{
label:'Created Time',
fieldName:'CreatedDate',
type:'date'
},
{
label:'End Time',
fieldName:'ClosedDate',
type:'date'
}
];

@wire(getActiveShift)
wiredActiveShift({ error, data }) {

    
    if (data) {
        let startHour=(data.Start_Time__c/10*60*60);
        let startMintue=(data.Start_Time__c/10*60);
        let startSecond=(data.Start_Time__c/10);

        let startTime=startHour+':'+startMintue+':'+startSecond;
        const regex = /^(\d{2}):(\d{2}):(\d{2})$/;

        data.Start_Time__c= regex.test(trimmed);  

        this.activeShift = data;
        this.shiftError = undefined;
    }
    if(error) {  
        this.shiftError = error;
    }
}

@wire(getAllCases)
wiredCases({error, data }) {
    if (data) {
        this.cases = data.map(
            row=>{
                return{
                ...row,
                OwnerName:row.Owner?row.Owner.Name:''
                }
            }
        );
        this.caseError = undefined;
    }
    if (error) {
        this.caseError = error;   
    }
}

navigateToConfig(){
    try{
    this[NavigationMixin.Navigate]({
      type: "standard__navItemPage",
      attributes: {
        apiName: 'Shift_Configuration_Page',
      },
    });
    console.log("navigation executed");
  }
  catch(error){
    console.error(error);
}
}
}